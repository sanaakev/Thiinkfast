// Placeholder for background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log("ThiinkFast Extension Installed");
});
